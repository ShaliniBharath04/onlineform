var express = require('express');
var mongoose = require('mongoose');

var config = "mongodb://localhost:27017/interview_db";
//import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
       <h2>Register Form</h2>
        <form class="was-validated">
	        <fieldset>
			<br/>
         <label>
           <input name="name" placeholder="Name" required /><br/>
         </label>
		   <label>
           <input age="age" placeholder="Age" /><br/>
         </label>
		   <label>
           <input occuption="occuption" placeholder="Occuption" /><br/>
         </label>
		 <label>
           <input email="email" placeholder="Email Id" required /><br/>
         </label>
       </fieldset>
       <button type="submit">Submit</button>

	  </form>
      </header>
	  
    </div>
  );
}


export default App;
